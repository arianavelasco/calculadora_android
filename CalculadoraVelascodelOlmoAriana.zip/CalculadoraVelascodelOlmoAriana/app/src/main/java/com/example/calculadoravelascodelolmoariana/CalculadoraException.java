package com.example.calculadoravelascodelolmoariana;

public class CalculadoraException extends Exception {

    public CalculadoraException(String message) {
        super(message);
    }
}
